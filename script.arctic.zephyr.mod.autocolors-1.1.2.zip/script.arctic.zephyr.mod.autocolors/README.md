![](https://raw.githubusercontent.com/semool/script.arctic.zephyr.mod.autocolors/master/icon.png)

## Arctic: Zephyr - Reloaded - Automatic Day/Night Colors

Install first: https://github.com/semool/script.module.astral/releases/

This little Addon switch the Skin Color Theme based on Time

The Time can set manualy or you can set your Location and the Theme will switch based on sunset/sunrise.

Disable the Automatic:
- Turn off this Addon
- Go to "Skin Settings - Furniture" and deactivate the Automatic
